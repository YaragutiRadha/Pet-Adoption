package com.java.major.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.java.major.global.GlobalData;
import com.java.major.repository.RoleRepository;
import com.java.major.repository.UserRepository;
import com.java.major.service.CategoryService;
import com.java.major.service.ProductService;

@Controller
public class HomeController {

    @Autowired
    CategoryService categoryService;

    @Autowired
    ProductService productService;
    
    @GetMapping({"/","/Home"})
    public String home(Model model) {
    	model.addAttribute("cartCount",GlobalData.cart.size());
    	return "index";
    }
    @GetMapping("/about")
	public String about(Model model) {
    	model.addAttribute("cartCount",GlobalData.cart.size());
		return "about";
	}
    
    @GetMapping("/shop")
    public String shop(Model model) {
        model.addAttribute("categories", categoryService.getAllCategory());  // Corrected service call
        model.addAttribute("products", productService.getAllProduct());      // Corrected method call
        model.addAttribute("cartCount",GlobalData.cart.size());
        return "shop";
    }

    @GetMapping("/shop/category/{id}")
    public String shopByCategory(Model model, @PathVariable int id) {
        model.addAttribute("categories", categoryService.getAllCategory());
        model.addAttribute("products", productService.getAllProductsByCategoryId(id));
        return "shop";
    }

    @GetMapping("/shop/viewproduct/{id}")
    public String viewProduct(Model model, @PathVariable int id) {  // Added @PathVariable annotation
        model.addAttribute("product", productService.getProductById(id).get());
        model.addAttribute("cartCount",GlobalData.cart.size());
        return "viewProduct";
    }
    
    
    
}
