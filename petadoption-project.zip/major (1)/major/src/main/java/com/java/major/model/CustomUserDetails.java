package com.java.major.model;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

public class CustomUserDetails extends User implements UserDetails {

    // Constructor to initialize CustomUserDetails from User
    public CustomUserDetails(User user) {
        super(user); // Call the constructor of the parent class
    }

    @Override
    public Collection<? extends GrantedAuthority> getAuthorities() {
        List<GrantedAuthority> authorities = new ArrayList<>();
        for (Role role : super.getRoles()) {
            if (role != null && role.getName() != null && !role.getName().isEmpty()) {
                authorities.add(new SimpleGrantedAuthority(role.getName()));
            } else {
                // Log or handle invalid role
                System.err.println("Invalid role detected: " + role);
            }
        }
        return authorities;
    }


    @Override
    public String getUsername() {
        // Using email as username
        return super.getEmail();
    }

    @Override
    public String getPassword() {
        // Return the password from the User class
        return super.getPassword();
    }

    @Override
    public boolean isAccountNonExpired() {
        return true;  // Your custom logic or default true
    }

    @Override
    public boolean isAccountNonLocked() {
        return true;  // Your custom logic or default true
    }

    @Override
    public boolean isCredentialsNonExpired() {
        return true;  // Your custom logic or default true
    }

    @Override
    public boolean isEnabled() {
        return true;  // Your custom logic or default true
    }
}
