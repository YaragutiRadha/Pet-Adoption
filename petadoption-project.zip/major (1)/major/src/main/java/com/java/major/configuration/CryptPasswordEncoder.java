package com.java.major.configuration;

public @interface CryptPasswordEncoder {

}
