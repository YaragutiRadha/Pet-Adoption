package com.java.major.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.java.major.model.Product;

public interface ProductRepository extends JpaRepository<Product, Long>{

	List<Product> findAll();

	List<Product> findAllByCategory_Id(int id);

}
